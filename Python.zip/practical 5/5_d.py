#sum all the items in dictionary
d = {1: 10, 2:20, 3:30, 4:40, 5:12, 6:34}
sum=0
for n in d.values():
    sum = sum + n
print(sum)
