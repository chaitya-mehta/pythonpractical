n = int(input("Enter the number: "))
print("The binary number: ", bin(n)[2:])
print("The hexadecimal number: ", hex(n)[2:])
print("The octal number: ", oct(n)[2:])