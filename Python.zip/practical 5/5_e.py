#to concate two dictionary
d1 = {1:"abhi", 2:"magan", 3:"chhagen"}
d2 = {4: "hello", 5:"Cale"}
d1.update(d2)
print(d1)