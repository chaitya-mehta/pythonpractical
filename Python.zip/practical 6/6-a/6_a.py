#create numbers from keyboard and stotre them into total.txt
# length = int(input("Enter the length: "))
# f = open("total.txt", 'w')
# for n in range(0, length):
#     a = input("Enter the number: ")
#     f.write(a)

with open("total.txt", 'w') as f:
    f.write("HEllooooooo")