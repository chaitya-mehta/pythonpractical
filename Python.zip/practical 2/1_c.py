a=int(input("Enter the number a: "))
b = int(input("Enter the number b: "))
a = a^b
b = a^b
a = a^b
print("The number a is ", a, " and the number b is ", b)
