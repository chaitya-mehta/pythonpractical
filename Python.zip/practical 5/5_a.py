# To map two lists into dictionary
l1 = [1,2,3]
#n = int(input("Enter the length: "))
l2 = ["maths", "computer"]
d = dict(zip(l1, l2))
print(d)