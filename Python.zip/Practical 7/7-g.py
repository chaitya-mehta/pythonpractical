# Write a program that calculates division of two vectors and returns the result vector using raise keyword and exception handling. 

