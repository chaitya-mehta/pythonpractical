d = {}
if d == {} :
    print("none")
